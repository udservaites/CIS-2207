#include "Car.h"


Car::Car(void)
{
}


Car::~Car(void)
{
}
