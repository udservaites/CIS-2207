#include "TestScores.h"
//You have to include the code in the header file for templates

/*TestScores::TestScores(void)
{
	score = 0;
}
*/
/*We need to make each of our functions templates as well*/
/*template <class T>
TestScores :: TestScores(T s) {
	score = s;
}

TestScores::~TestScores(void)
{
}*/


 
