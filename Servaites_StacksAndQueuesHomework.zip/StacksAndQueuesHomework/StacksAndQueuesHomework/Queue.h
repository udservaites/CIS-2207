#pragma once
class Queue
{
public:
	Queue();
	~Queue();
};

