#include "Parentheses.h"


Parentheses::Parentheses()
{
	parenthesis = '(';
}


Parentheses::~Parentheses()
{
}
