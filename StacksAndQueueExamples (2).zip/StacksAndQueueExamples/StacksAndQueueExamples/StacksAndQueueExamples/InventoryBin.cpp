#include "InventoryBin.h"


InventoryBin::InventoryBin(void)
{
}


InventoryBin::~InventoryBin(void)
{
}
