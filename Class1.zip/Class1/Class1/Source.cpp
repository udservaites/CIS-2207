/*File that has the main, will generally be known as the driver file*/

/*For homework*/

//Name
//CIS 2207
//Date
//problem number
//Description of problem

#include <iostream>

using namespace std;

int getNumberCars();
void foo(int number);
void bar(string line);

int main() {

	int variable1, variable2; //Couple of int variables

	variable1 = 4;
	variable2 = 5;

	if(variable1 > variable2) {
		cout <<"Greater" << endl;
		int difference = variable1 - variable2; //You can creat a new variable here, if you want
		//It will only exist with this statement, not outside the if statement block.
	}
	else {
		cout << "Less" <<endl;

		cout << (variable1 > variable2) << endl; //This will print out a boolean, it will print a 0 or 1, 0 for false

		cout << ((variable1 > variable2)?"Greater":"Less")<< endl;/*Bit wide shift has higher presendaence over in line
																 if statement, */
		/*In-line if statement: question mark is if, colon is else. If true, use the left of the colon, else use right of colon*/
	}

	/*File commands are different in C++ as well. Use string operators to read a file*/
	/*To have main at the top of the program, you must use prototype. */

	int numberCars = getNumberCars();
	
	foo(5);
	foo(); //What happens if you don't use an arguement?
	/* */
	bar("Hello World");

	

	cout << "There are " << numberCars << " in the parking lot" << endl;


	system("pause"); //Pauses the program and keeps it on the screen.
	return(0);
}

int getNumberCars() {

	int number;

	cout << "Enter number of cars: "; /*This is our output to the console*/
	cin >> number; /*Take the standard input and try to put it into the variable number. You don't have to specify
				   what the variable is like in c, the compiler will do it for you.*/
	/*What if we want to do some validation?*/
	while (number < 0) {
		cout << "Enter a POSITIVE number of cars: ";
		cin >> number;
		/*In a for loop and a while loop there are two evil commands, break and continue. You can use the break command
		to exit a loop. It gives multiple ways of exiting a control structure. If you use continue it will ignore subsequent
		commands in a loop and go to the next5 iteration. Good programming style has one exit for the control structure of a 
		loop. The "go to" statement is not ever to be used. Throw is used for exceptions. */

		/*There is very little reason to ever use a static variable. static int variable --> memory is allocated at the 
		creation of teh program and has the same memory location every time it is called and the same value. It is a 
		permanent assignment*/

		

	return number;
}
	/*Default arguements: */

	void foo(int number) { 

		for (int i = 0; i < number; i++) {
			cout << "*";
		}
	}

	/*For a no arguement in main you can do this: */
	void foo(int number = 10) { /*Giving a default value for an arguement, if you have multiple arguements, they must be done
								in order, they must be the last arguements, not default arguments must be listed first*/

		for (int i = 0; i < number; i++) {
			cout << "*";
		}
	}

	/*Passing by reference: Using a variable instaed of a number in the arguement. They are different variables, 
	but they have the same value. foo(int number) --> creates a new variable
	foo(int &number) By reference means, do not create a new variable, use the same memory slot as teh 
	variable you are passing. It is slightly more efficient, becuase you dont have to creat a new variable. 
	We do it because other programming languages do it. 
	By default, it is passed by value. */

	/*if you want to pass a c style string, include the string methods. You can use the string class, 
	but not fully without the string class. #incude <string>
	*/

	void bar(string line) {
		cout << line << endl;
	}

	string foobar() {
		cout << "Enter a line: ";
		string line;
		cin>>line; //Reads in one word a time. Seperated by white space
	//Instead of cin >> line do this:
		getline(cin, line); //Looks for the \n when you hit the enter key and stops reading there. 

		return line;
	}