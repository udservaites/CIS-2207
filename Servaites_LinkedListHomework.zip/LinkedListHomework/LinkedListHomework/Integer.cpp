#include "Integer.h"


Integer::Integer()
{
}

Integer::Integer(int num) {
	integer = num;
}

Integer::~Integer()
{
}
