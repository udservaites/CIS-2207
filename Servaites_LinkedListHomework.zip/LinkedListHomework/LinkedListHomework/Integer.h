#pragma once
class Integer
{
private:
	int integer;
public:
	Integer();
	Integer(int num);
	~Integer();
};

